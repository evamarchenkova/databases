from flask import Flask
from data import db_session
from data.users import User
from data.jobs import Jobs

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

db_session.global_init("db/mars_explorer.sqlite")
session = db_session.create_session()
user1 = User(surname='Scott', name='Ridley', age='21', position='captain',
             speciality='research engineer', address='module_1', email='scott_chief@mars.org')
session.add(user1)
user2 = User(surname='Marchenkova', name='Eve', age='16', position='student',
             speciality='very important profession', address='Yekaterinburg', email='eve.march@mail.ru')
session.add(user2)
user3 = User(surname='Nababkahk', name='Tape', age='20', position='president',
             speciality='rapper', address='Moscow', email='djtape@flex.com')
session.add(user3)
user4 = User(surname='Dubova', name='Asya', age='16', position='student',
             speciality='very secret information', address='Sortirovka', email='anastasya.dub@yandex.ru')
session.add(user4)

session.commit()


def main():
    app.run()


if __name__ == '__main__':
    main()
